package interfaces;
import classes.*;

public interface GradeOperations{
	
	void showGrade(double midMarks, double finalMarks);
}